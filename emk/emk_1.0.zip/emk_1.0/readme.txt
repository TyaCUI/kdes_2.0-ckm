(1) Run the demo code imagenetsmall_cksvd on a small imagenet dataset
(2) To run the demo code caltech101_cksvd,  download caltech101 dataset at http://www.vision.caltech.edu/Image_Datasets/Caltech101/101_ObjectCategories.tar.gz, rename the data folder as caltech101, and copy it to the directory ./images/. Don't forget to remove tmp file in BACKGROUND_Google category 

send me an email(liefengbo@gmail.com) if you have any difficulty to run the code

